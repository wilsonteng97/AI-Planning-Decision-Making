from setuptools import setup

setup(name='agent',
    version='0.0.1',
    install_requires=['runner'],
    packages=['agent']
)
